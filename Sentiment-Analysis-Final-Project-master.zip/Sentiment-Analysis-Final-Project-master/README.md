# Sentiment-Analysis-Final-Project
Final Project of Bachelor Degree "Information System" Del Insitute of Technology
